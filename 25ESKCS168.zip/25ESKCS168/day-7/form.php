!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="registration.php" method="get",</form>
    <input type="text" name="name" placeholder="Enter your name">
    <input type="email" name="email" placeholder="Enter your email">
    <input type="text" name="branch" placeholder="Enter your branch">
    <input type="text" name="phonenumber" placeholder="Enter your phone number">
    <button type="submit">Submit</button>
</body>
</html>