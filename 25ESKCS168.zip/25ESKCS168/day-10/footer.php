<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

        <footer class="bg-dark text-white text center py-3 mt-5">
            <p class="mb-0"> &copy; <?php echo date("y"); ?> My website. All rights reserved.</p>
        </footer>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" rel="stylesheet"></script>
</body >
</html >