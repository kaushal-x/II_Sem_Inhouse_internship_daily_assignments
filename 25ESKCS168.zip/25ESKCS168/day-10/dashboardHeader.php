<?php
if (!isset($_SESSION["user_name"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">            
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"> 
</head>

<body>
    <header class="bg-light border-bottom">
        <div class="container">
            <div class="d-flex" justify-content-between align-items-center py-3">

                <!--logo -->
                <img src="" alt="logo" width="80" 
                <nav>
                <ul class="nav">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link text-dark">Home</a>
                    </li>

                    <li class="nav-item">
                        <a href="about.php" class="nav-link text-dark">About us</a>
                    </li>
                    <li class="nav-item">
                        <a href="contact.php" class="nav-link text-dark">Contact us</a>
                    </li>
                </ul>
                </nav>

                <button type="button" class="btn btn-primary">
                    logout
                </button>
            </div>
        </div>
    </header>
</body>

</html>